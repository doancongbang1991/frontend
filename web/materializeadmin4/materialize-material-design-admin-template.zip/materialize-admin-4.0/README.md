Product Name
---------------
Materialize - Material Design Admin Template


Product Description
-------------------
#1 Selling & Most Popular Material Design Admin Template of All Time
Join The 2,500+ Satisfied Customers Today


Online Documentation
--------------------
You will find documentation in your downloaded zip file from ThemeForest. You can access documentation online as well.
Documentation URL: http://demo.geekslabs.com/materialize/documentation
